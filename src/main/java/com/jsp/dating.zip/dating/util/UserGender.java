package com.jsp.dating.util;

public enum UserGender {
	MALE, FEMALE;
}
